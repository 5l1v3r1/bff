jmfoote@cert.org

5/7/2013:
All of the PIN tool binaries have been built against PIN kit rev 58423.
Windows binaries were built using the VC10 compiler kit.
If your system doesn't match this version, you can rebuild the tool:
  On Linux, try make.py
  On Windows, try make.bat